<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;


/* @var $this yii\web\View */
/* @var $model common\models\UserModel */

$this->title = '添加用户';
$this->params['breadcrumbs'][] = ['label' => '超级用户', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="box">
	<div class="box-header with-border">
	  <div class="box-title"> 添加用户</div>
	</div>
	<div class="box-body">

	<?php $form = ActiveForm::begin([
	    'fieldConfig' => [
	        'template' => '<div class="row"><div class="col-lg-1">{label}</div><div class="col-lg-11"><div class="col-lg-8">{input}</div><div>{error}</div></div></div>',
	    ],  
	]); ?>
	
    <?= $form->field($model, 'username')->textInput() ?>

	<?= $form->field($model, 'password')->passwordInput() ?>
	
	<?= $form->field($model, 'email')->textInput() ?>
	
	<?= $form->field($model, 'status')->dropDownList([0=>'未激活',1=>'已激活']) ?>
	
	<div class="form-group">
	    <?= Html::submitButton('保存', ['class' => 'btn btn-primary btn-flat']) ?>
	</div>
	
	<?php ActiveForm::end(); ?>
    
    </div>
</div>


