<?php

use yii\helpers\Html;
use yii\grid\GridView;
use mdm\admin\components\Helper;

/* @var $this yii\web\View */
/* @var $searchModel mdm\admin\models\searchs\User */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '超级用户';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-index">
	<div class="box">
		<div class="box-header with-border">
			<div class="box-title"><?=$this->title?></div>
		</div>
		<div class="box-body">
			
			<?= $this->render('_search', [
		        'model' => $searchModel,
		    ]) ?>
			
			<?=
		    GridView::widget([
		    	'tableOptions' => ['class'=>'table table-bordered table-hover'],
		        'dataProvider' => $dataProvider,
		    	'summary' => false,
		        'columns' => [
		            ['class' => 'yii\grid\SerialColumn'],
		        	'id',
		            'username',
		            'email:email',
		            'created_at:date',
		            [
		                'attribute' => 'status',
		                'value' => function($model) {
		                    return $model->status == 0 ? '未激活' : '已激活';
		                },
		                'filter' => [
		                    0 => '未激活',
		                    10 => '已激活'
		                ]
		            ],
		            [
		                'class' => 'yii\grid\ActionColumn',
		                'template' => Helper::filterActionColumn(['view','update', 'change-password', 'activate', 'delete']),
		                'buttons' => [
		                	'view' => function ($url, $model){
		                		return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', ['assignment/view','id'=>$model->id], ['title'=>'权限分配']);
		               		},
		                    'change-password' => function($url, $model){
		                    	return Html::a('<span class="glyphicon glyphicon-lock"></span>', $url, ['title'=>'修改密码']);
		                    },
		                    'activate' => function($url, $model) {
		                    $options = [
		                    		'title' => Yii::t('rbac-admin', ($model->status == 10)?'禁用':'激活'),
		                    		'aria-label' => Yii::t('rbac-admin', 'Activate'),
		                    		'data-confirm' => Yii::t('rbac-admin', '确定'.(($model->status == 10)?'禁用':'激活').'这个用户吗？'),
		                    		'data-method' => 'post',
		                    		'data-pjax' => '0',
		                    ];
		                    if ($model->status == 10) {
		                    	return Html::a('<span class="glyphicon glyphicon-remove"></span>', $url, $options);
		                    }
		                    return Html::a('<span class="glyphicon glyphicon-ok"></span>', $url, $options);
		                    },
		               ],     
		            ],
		        ],
		    ]);?>
		</div>
	</div>
</div>
