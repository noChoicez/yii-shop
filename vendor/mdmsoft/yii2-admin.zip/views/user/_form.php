<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\AdminModel */
/* @var $form yii\widgets\ActiveForm */
?>

<?php $form = ActiveForm::begin([
    'fieldConfig' => [
        'template' => '<div class="row"><div class="col-lg-1">{label}</div><div class="col-lg-11"><div class="col-lg-8">{input}</div><div>{error}</div></div></div>',
    ],  
]); ?>

<?= $form->field($model, 'username')->textInput() ?>

<?= $form->field($model, 'email')->textInput() ?>

<?= $form->field($model, 'status')->dropDownList([0=>'未激活',1=>'已激活']) ?>

<div class="form-group">
    <?= Html::submitButton('保存', ['class' => 'btn btn-primary btn-flat']) ?>
</div>

<?php ActiveForm::end(); ?>


