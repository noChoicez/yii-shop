<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model mdm\admin\models\Menu */

$this->title = Yii::t('rbac-admin', 'Update Menu');
$this->params['breadcrumbs'][] = ['label' => Yii::t('rbac-admin', 'Menus'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="menu-update">
<div class="box">
	<div class="box-header with-border">
	  <div class="box-title"><?= Html::encode($this->title) ?></div>
	</div>
	<div class="box-body">
    <?=
    $this->render('_form', [
        'model' => $model,
    ])
    ?>
    </div>
</div>
</div>
