<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $searchModel mdm\admin\models\searchs\Menu */

$this->title = Yii::t('rbac-admin', 'Menus');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="menu-index">
<div class="box">
	<div class="box-header with-border">
	  <div class="box-title">菜单列表</div>
	</div>
	<div class="box-body">
    <?php echo $this->render('_search', ['model' => $searchModel]);  ?>

    <?php Pjax::begin(); ?>
    <?=
    GridView::widget([
    	'tableOptions' => ['class'=>'table table-bordered table-hover'],
        'summary'=>'',
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'name',
            [
                'attribute' => 'menuParent.name',
                'filter' => Html::activeTextInput($searchModel, 'parent_name', [
                    'class' => 'form-control', 'id' => null
                ]),
                'label' => Yii::t('rbac-admin', 'Parent'),
            ],
            'route',
            [
            	'attribute' => 'order',
            	'format' => 'raw',
            	'value' => function($model){
            		return Html::input('text', 'order', $model->order, [
            			'class'=>'order-input',
            			'onchange'=>'updateField("'.Url::to(['menu/ajax']).'",'.$model->id.',"order",this.value)',
            			'onkeyup' => 'this.value=this.value.replace(/[^\d]/g,"")',
            		]);
                },
                'headerOptions' => [
                	'width' => '70px',
                ],
    		],
            [
                'class' => 'yii\grid\ActionColumn',
                'header'=>'操作',
            ],
        ],
    ]);
    ?>
<?php Pjax::end(); ?>
	</div>
</div>
</div>
