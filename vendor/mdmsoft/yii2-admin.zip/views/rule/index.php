<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this  yii\web\View */
/* @var $model mdm\admin\models\BizRule */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $searchModel mdm\admin\models\searchs\BizRule */

$this->title = Yii::t('rbac-admin', 'Rules');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="role-index">
	<div class="box">
		<div class="box-header with-border">
			<div class="box-title"><?= Html::encode($this->title) ?></div>
		</div>
		<div class="box-body">
			<div class="form-group">
				<?= Html::a(Yii::t('rbac-admin', 'Create Rule'), ['create'], ['class' => 'btn btn-info btn-flat']) ?>
			</div>
			
			<?=
		    GridView::widget([
		    	'tableOptions' => ['class'=>'table table-bordered table-hover'],
		        'dataProvider' => $dataProvider,
		        //'filterModel' => $searchModel,
		        'columns' => [
		            ['class' => 'yii\grid\SerialColumn'],
		            [
		                'attribute' => 'name',
		                'label' => Yii::t('rbac-admin', 'Name'),
		            ],
		            ['class' => 'yii\grid\ActionColumn',],
		        ],
		    ]);
		    ?>
		</div>
	</div> 
</div>
