<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this  yii\web\View */
/* @var $model mdm\admin\models\BizRule */
/* @var $form ActiveForm */
?>

<div class="auth-item-form">
	<div class="box">
		<div class="box-header with-border">
			<div class="box-title"><?=Html::encode($this->title)?></div>
		</div>
		<div class="box-body">
			<?php $form = ActiveForm::begin(); ?>

		    <?= $form->field($model, 'name')->textInput(['maxlength' => 64]) ?>
		
		    <?= $form->field($model, 'className')->textInput() ?>
		
		    <div class="form-group">
		        <?php
		        echo Html::submitButton($model->isNewRecord ? Yii::t('rbac-admin', 'Update') : Yii::t('rbac-admin', 'Update'), [
		            'class' => 'btn btn-primary btn-flat'])
		        ?>
		    </div>
		
		    <?php ActiveForm::end(); ?>	
		</div>
	</div>
	
    
</div>
