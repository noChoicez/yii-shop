<?php
namespace mdm\admin\models\form;

use Yii;
use mdm\admin\models\User;
use yii\base\Model;

/**
 * Signup form
 */
class Signup extends Model
{
	public $id;
    public $username;
    public $email;
    public $password;
    public $status;
    
    public $_lastError;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            ['username', 'filter', 'filter' => 'trim'],
            ['username', 'required'],
            ['username', 'unique', 'targetClass' => 'mdm\admin\models\User', 'message' => '用户名已存在'],
            ['username', 'string', 'min' => 2, 'max' => 255],

            ['email', 'filter', 'filter' => 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'unique', 'targetClass' => 'mdm\admin\models\User', 'message' => '邮箱已存在'],

            ['password', 'required'],
            ['password', 'string', 'min' => 6],
        	['status', 'default', 'value' => 10],
        ];
    }
	
    public function attributeLabels()
    {
    	return [
    		'username' => '用户名',
    		'password' => '密码',
    		'email' => '邮箱',
    		'status' => '状态',
    	];
    }
    
    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function signup()
    {
    	$transaction = Yii::$app->db->beginTransaction();
    	try {
    		$user = new User();
    		$user->username = $this->username;
    		$user->email = $this->email;
    		$user->setPassword($this->password);
    		$user->generateAuthKey();
    		$user->status = $this->status;
    		if (!$user->save()) {
    			throw new \Exception('用户添加失败');
    		}
    		$this->id = $user->id;
    		
    		$transaction->commit();
    		return true;
    	} catch (\Exception $e) {
    		$transaction->rollBack();
    		$this->_lastError = $e->getMessage();
    		return false;
    	}
    }
}
